tmate
=====

What is it?
-----------

Tmate is a fork of tmux. It provides an instant pairing solution.

License
-------

tmate is built on top of tmux. tmux and tmate are BSD-licensed.
